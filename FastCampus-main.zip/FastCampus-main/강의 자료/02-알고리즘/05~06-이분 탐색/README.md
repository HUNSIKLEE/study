|문제 이름|문제 링크|답안 코드 링크|
|---|---|---|
|먹을 것인가 먹힐 것인가|[링크](http://boj.kr/7795)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/7795-먹을%20것인가%20먹힐%20것인가)|
|두 용액|[링크](http://boj.kr/2470)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/2470-두%20용액)|
|나무 자르기|[링크](http://boj.kr/2805)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/2805-나무%20자르기)|
|공유기 설치|[링크](http://boj.kr/2110)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/2110-공유기%20설치)|
|**연습문제**|||
|수 찾기|[링크](http://boj.kr/1920)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/1920-수%20찾기)|
|듣보잡|[링크](http://boj.kr/1764)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/1764-듣보잡)|
|두 수의 합|[링크](http://boj.kr/3273)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/3273-두%20수의%20합)|
|숫자 카드 2|[링크](http://boj.kr/10816)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/10816-숫자%20카드%202)|
|랜선 자르기|[링크](http://boj.kr/1654)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/1654-랜선%20자르기)|
|예산|[링크](http://boj.kr/2512)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/2512-예산)|
|기타 레슨|[링크](http://boj.kr/2343)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/2343-기타%20레슨)|
|용돈 관리|[링크](http://boj.kr/6236)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/6236-용돈%20관리)|
|이상한 술집|[링크](http://boj.kr/13702)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/13702-이상한%20술집)|
|어두운 굴다리|[링크](http://boj.kr/17266)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/17266-어두운%20굴다리)|
|K번째 수|[링크](http://boj.kr/1300)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/1300-K%20번째%20수)|
|날카로운 눈|[링크](http://boj.kr/1637)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/05~06-이분%20탐색/문제별%20코드/1637-날카로운%20눈)|