|문제 이름|문제 링크|답안 코드 링크|
|---|---|---|
|트리의 부모 찾기|[링크](http://boj.kr/11725)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/12-트리/문제별%20코드/11725-트리의%20부모%20찾기)|
|트리|[링크](http://boj.kr/1068)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/12-트리/문제별%20코드/1068-트리)|
|**연습문제**|||
|트리|[링크](http://boj.kr/4803)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/12-트리/문제별%20코드/4803-트리)|
|트리 순회|[링크](http://boj.kr/1991)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/12-트리/문제별%20코드/1991-트리%20순회)|
|이진 검색 트리|[링크](http://boj.kr/5639)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/12-트리/문제별%20코드/5639-이진%20검색%20트리)|
|나무 탈출|[링크](http://boj.kr/15900)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/12-트리/문제별%20코드/15900-나무%20탈출)|
|부동산 다툼|[링크](http://boj.kr/20364)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/12-트리/문제별%20코드/20364-부동산%20다툼)|
|가장 가까운 공통 조상|[링크](http://boj.kr/3584)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/12-트리/문제별%20코드/3584-가장%20가까운%20공통%20조상)|
|노드사이의 거리|[링크](http://boj.kr/1240)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/12-트리/문제별%20코드/1240-노드%20사이의%20거리)|
|사촌|[링크](http://boj.kr/9489)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/12-트리/문제별%20코드/9489-사촌)|
|트리와 쿼리|[링크](http://boj.kr/15681)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/12-트리/문제별%20코드/15681-트리와%20쿼리)|
|회사 문화 1|[링크](http://boj.kr/14267)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/12-트리/문제별%20코드/14267-회사%20문화%201)|