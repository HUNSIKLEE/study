|문제 이름|문제 링크|답안 코드 링크|
|---|---|---|
|DFS와 BFS|[링크](http://boj.kr/1260)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-%EA%B7%B8%EB%9E%98%ED%94%84%20%ED%83%90%EC%83%89/%EB%AC%B8%EC%A0%9C%EB%B3%84%20%EC%BD%94%EB%93%9C/1260-DFS%EC%99%80%20BFS)|
|단지번호붙이기|[링크](http://boj.kr/2667)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/2667-단지번호%20붙이기)|
|물통|[링크](http://boj.kr/2251)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/2251-물통)|
|연구소|[링크](http://boj.kr/14502)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/14502-연구소)|
|미로 탐색|[링크](http://boj.kr/2178)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/2178-미로%20탐색)|
|숨바꼭질|[링크](http://boj.kr/1697)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/1697-숨바꼭질)|
|탈출|[링크](http://boj.kr/3055)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/3055-탈출)|
|**연습문제**|||
|유기농 배추|[링크](http://boj.kr/1012)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/1012-유기농%20배추)|
|연결 요소의 개수|[링크](http://boj.kr/11724)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/11724-연결%20요소의%20개수)|
|섬의 개수|[링크](http://boj.kr/4963)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/4963-섬의%20개수)|
|양|[링크](http://boj.kr/3184)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/3184-양)|
|바이러스|[링크](http://boj.kr/2606)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/2606-바이러스)|
|경로 찾기|[링크](http://boj.kr/11403)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/11403-경로%20찾기)|
|트리의 부모 찾기|[링크](http://boj.kr/11725)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/11725-트리의%20부모%20찾기)|
|나이트의 이동|[링크](http://boj.kr/7562)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/7562-나이트의%20이동)|
|촌수계산|[링크](http://boj.kr/2644)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/2644-촌수%20계산)|
|현명한 나이트|[링크](http://boj.kr/18404)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/18404-현명한%20나이트)|
|케빈 베이컨의 6단계 법칙|[링크](http://boj.kr/1389)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/1389-케빈%20베이컨의%206단계%20법칙)|
|결혼식|[링크](http://boj.kr/5567)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/5567-결혼식)|
|토마토|[링크](http://boj.kr/7569)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/09~11-그래프%20탐색/문제별%20코드/7569-토마토)|