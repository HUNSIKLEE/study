|문제 이름|문제 링크|답안 코드 링크|
|---|---|---|
|최소비용 구하기|[링크](http://boj.kr/1916)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/14-최단거리/문제별%20코드/1916-최소비용%20구하기)|
|최단경로|[링크](http://boj.kr/1753)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/14-최단거리/문제별%20코드/1753-최단경로)|