|문제 이름|문제 링크|답안 코드 링크|
|---|---|---|
|N과 M (3)|[링크](http://boj.kr/15651)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/01~02-완전%20탐색/문제별%20코드/15651-N과%20M(3))|
|N과 M (1)|[링크](http://boj.kr/15649)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/01~02-완전%20탐색/문제별%20코드/15649-N과%20M(1))|
|N과 M (4)|[링크](http://boj.kr/15652)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/01~02-완전%20탐색/문제별%20코드/15652-N과%20M(4))|
|N과 M (2)|[링크](http://boj.kr/15650)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/01~02-완전%20탐색/문제별%20코드/15650-N과%20M(2))|
|연산자 끼워넣기|[링크](http://boj.kr/14888)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/01~02-완전%20탐색/문제별%20코드/14888-연산자%20끼워넣기)|
|N-Queen|[링크](http://boj.kr/9663)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/01~02-완전%20탐색/문제별%20코드/9663-N%20Queen)|
|**연습문제**|
|부분수열의 합|[링크](http://boj.kr/1182)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/01~02-완전%20탐색/문제별%20코드/1182-부분수열의%20합)|
|암호 만들기|[링크](http://boj.kr/1759)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/01~02-완전%20탐색/문제별%20코드/1759-암호%20만들기)|
|N과 M (9)|[링크](http://boj.kr/15663)|[링크](https://github.com/rhs0266/FastCampus/tree/main/%EA%B0%95%EC%9D%98%20%EC%9E%90%EB%A3%8C/02-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/01~02-완전%20탐색/문제별%20코드/15663-N과%20M(9))|